import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { FooterComponent } from './komponenti/footer/footer.component';
import { NavComponent } from './komponenti/nav/nav.component';
import { StranicarComponent } from './komponenti/stranicar/stranicar.component';
import { FilmContainerComponent } from './komponenti/film-container/film-container.component';
import { PrijavaComponent } from './stranice/prijava/prijava.component';
import { RegistracijaComponent } from './stranice/registracija/registracija.component';
import { ProfilComponent } from './stranice/profil/profil.component';
import { Routes, RouterModule } from '@angular/router';
import { GuestGuard } from './servisi/guest-check.service';
import { LoggedGuard } from './servisi/logged-check.service';
import { AdminGuard } from './servisi/admin-check.service';
import { DokumentacijaComponent } from './stranice/dokumentacija/dokumentacija.component';
import { PocetnaComponent } from './stranice/pocetna/pocetna.component';
import { FilmComponent } from './stranice/film/film.component';
import { FilmoviPregledComponent } from './stranice/filmovi-pregled/filmovi-pregled.component';
import { FilmoviPrijedloziComponent } from './stranice/filmovi-prijedlozi/filmovi-prijedlozi.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ZanroviComponent } from './stranice/zanrovi/zanrovi.component';
import { PostavkeZanraComponent } from './komponenti/postavke-zanra/postavke-zanra.component';
import { ReCaptchaComponent } from './komponenti/re-captcha/re-captcha.component';
import { FilmKarticaComponent } from './komponenti/film-kartica/film-kartica.component';
import { StranicaNePostojiComponent } from './stranice/stranica-ne-postoji/stranica-ne-postoji.component';

const routes: Routes = [
    { path: '', component: PocetnaComponent },
    { path: 'dokumentacija', component: DokumentacijaComponent },
    { path: 'profil', component: ProfilComponent, canActivate: [GuestGuard] },
    { path: 'prijava', component: PrijavaComponent, canActivate: [LoggedGuard]  },
    { path: 'film/:id', component: FilmComponent },
    { path: 'filmoviPregled', component: FilmoviPregledComponent, canActivate: [GuestGuard] },
    { path: 'registracija', component: RegistracijaComponent, canActivate: [LoggedGuard] },
    { path: 'filmoviPrijedlozi', component: FilmoviPrijedloziComponent, canActivate: [AdminGuard] },
    { path: 'zanrovi', component: ZanroviComponent, canActivate: [AdminGuard] },
    { path: 'odjava', component: PocetnaComponent, canActivate: [LoggedGuard] },
    { path: '**', component: StranicaNePostojiComponent },
]

@NgModule({
    declarations: [
        AppComponent,
        FooterComponent,
        NavComponent,
        StranicarComponent,
        FilmContainerComponent,
        PrijavaComponent,
        RegistracijaComponent,
        ProfilComponent,
        DokumentacijaComponent,
        PocetnaComponent,
        FilmComponent,
        FilmoviPregledComponent,
        FilmoviPrijedloziComponent,
        ZanroviComponent,
        PostavkeZanraComponent,
        ReCaptchaComponent,
        FilmKarticaComponent,
        StranicaNePostojiComponent,
    ],
    imports: [
        BrowserModule,
        RouterModule.forRoot(routes),
        HttpClientModule,
        FormsModule,
    ],
    providers: [],
    bootstrap: [AppComponent]
})

export class AppModule { }
