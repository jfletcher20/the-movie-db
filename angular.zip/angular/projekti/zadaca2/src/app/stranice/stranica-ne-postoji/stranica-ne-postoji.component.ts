import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-stranica-ne-postoji',
    templateUrl: './stranica-ne-postoji.component.html',
    styleUrls: ['./stranica-ne-postoji.component.scss']
})

export class StranicaNePostojiComponent implements OnInit {

    sec: number = 3;

    constructor(private router: Router) {
    }

    ngOnInit(): void {
        setTimeout(() => this.sec--, 1000)
        setTimeout(() => this.sec--, 2000)
        setTimeout(() => this.sec--, 3000)
        setTimeout(() => this.router.navigate(['/']), 4000);
    }

}
