import { Component, OnInit } from '@angular/core';
import { okolina } from '../../../environments/environment';
// import { DocSelectors } from '../../app.component';
import { Pager } from '../../komponenti/stranicar/stranicar.component';

@Component({
    selector: 'app-filmovi-prijedlozi',
    templateUrl: './filmovi-prijedlozi.component.html',
    styleUrls: ['./filmovi-prijedlozi.component.scss']
})
export class FilmoviPrijedloziComponent implements OnInit {

    filmovi: any;
    ngOnInit() {
        this.ucitajStranicu();
    }

    async ucitajStranicu() {

        let filmContainer = document.getElementsByClassName("film-container")[0];
        let brojStranica = await maxStranica();
        let filmovi = await dohvatiFilmove();
        this.filmovi = filmovi;

        let c = 0;

        // console.log(filmovi);
        if(await filmovi.length > 0) {

            for(let j = 0; j < filmovi.length; j++) {

                // if(filmovi[j]["prijedlog"] == 1) {

                    let id = filmovi[j]["id"];
                    let naslov = filmovi[j]["naslov"];
                    let datum = filmovi[j]["datum_izlaska"];
                    datum = datum.substring(8, 10) + "." + datum.substring(5, 7) + "." + datum.substring(0, 4) + ".";
                    let poster = await filmovi[j]["poster_putanje"];
                    let posterURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
                    let hide = (++c > brojStranica) ? ' hidden' : '';
                    let film = '<div class="film" ' + hide + '>'
                            // + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" id="' + id + '">'
                            + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" class="id-' + id + '">'
                            + '<img src="' + posterURL + poster + '" alt="Poster slika filma"></a>'
                            + '<button class="btn-prihvati" id="prihvati-' + id + '">PRIHVATI</button>'
                            + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" class="id-' + id + '">'
                            + '<h1 style="transform: translateY(-2rem) !important">' + naslov + '</h1>'
                            + '<p style="transform: translateY(-2rem) !important">'
                                + datum
                            + '</p>'
                        + '</a></div>';
                    
                    filmContainer.innerHTML += film;

                // }

            }

        }

        let prihvatiGumbovi = document.getElementsByClassName('btn-prihvati');
        for(let i = 0; i < prihvatiGumbovi.length; i++) {
            prihvatiGumbovi[i].addEventListener("click", (e) => {
                // document.getElementById(getTargetId(e.target)).parentElement.remove();
                this.getParent(this.getElementById(this.getTargetId(e.target)))?.remove();
                prihvatiFilm(this.getTargetId(e.target).split("-")[1]);
                try { new Pager(brojStranica, 'needs-pager').showPage(); }
                catch(e) {};
            })
        }

        new Pager(brojStranica, 'needs-pager').showPage();

    }

    private getTargetId(target: any) {
        return target.id ?? null;
    }
    
    private getElementById(id: any) {
        return document.getElementById(id) ?? null;
    }

    private getParent(element: any) {
        return element.parentElement ?? null;
    }
    
}

// const htmlUpravitelj = require("../htmlUpravitelj.js")

let url = new okolina().app();

async function maxStranica() {
    let odgovor = await fetch(url + "/brojStranica");
    let podaci = await odgovor.text();
    let brojStranica = JSON.parse(podaci);
    // console.log("OKTRIVENO ", brojStranica)
    return brojStranica;
}

async function dohvatiFilmove() {
    let odgovor = await fetch(url + "/dajSveFilmove?prijedlozi=1");
    let podaci = await odgovor.text();
    let filmovi = JSON.parse(podaci);
    return filmovi;
}

async function prihvatiFilm(id: any) {
    if(id == null) return;
    let odgovor = await fetch(url + "/film/" + id + "/prihvati");
    let podaci = await odgovor.text();
    console.log("accepting film", id);
    return { status: "OK", code: 200 };
}