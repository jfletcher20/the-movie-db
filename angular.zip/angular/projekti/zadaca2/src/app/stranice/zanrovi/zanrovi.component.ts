import { Component, OnInit } from '@angular/core';
import { okolina } from '../../../environments/environment';
import { DocSelectors } from '../../app.component';



@Component({
    selector: 'app-zanrovi',
    templateUrl: './zanrovi.component.html',
    styleUrls: ['./zanrovi.component.scss']
})

export class ZanroviComponent implements OnInit {

    // // const htmlUpravitelj = require("../htmlUpravitelj.js")
    url: string;
    zanroviBaza: any;

    constructor(){
        this.url = new okolina().app();
    }

    async loadBazaZanrovi() {

        console.log("LOADING BAZA ZANROVI")

        let popisZanrovaBaza = (document.getElementById("popis-zanrova-baza") as HTMLElement);
        popisZanrovaBaza.innerHTML = "";

        this.zanroviBaza = await this.dohvatiZanroveIzBaze();

        if(this.zanroviBaza.length == 0) {
            popisZanrovaBaza.innerHTML = "Nema pohranjenih zanrova u bazi podataka."
            return;
        }

        for(let i = 0; i < this.zanroviBaza.length; i++) {
            let zanrHTML = "<li id='baza-item-" + i + "' class='zanr-baza'>" +
                                "<input id='baza-btn-" + i + "' class='zanr-baza-btn' " +
                                "type='button' value='Ukloni'" +
                                "placeholder='" + JSON.stringify(this.zanroviBaza[i]) + "'>" +
                                " <input id='baza-btn-edit-" + i +
                                "' class='zanr-baza-btn-edit' type='button' value='Ažuriraj'" +
                                "placeholder='" + JSON.stringify(this.zanroviBaza[i]) + "'>" +
                                "\t" + this.zanroviBaza[i]["naziv"] +
                           "</li>";
            popisZanrovaBaza.innerHTML += zanrHTML;
        }

        this.loadBrisiSve(popisZanrovaBaza);
        
        setTimeout(() => this.addListeners(popisZanrovaBaza), 100);

    }

    it: number = 0;
    loadBrisiSve(ref: any) {
        
        if(this.it++ == 0) {
            
            ref.outerHTML += "<input id='ukloni-sve' class='zanr-baza-btn'" +
                                " type='button' value='Ukloni sve nereferencirane zanrove'>";
            (document.getElementById('ukloni-sve') as HTMLElement).addEventListener("click", () => {
                console.log("uklanjamo sve.")
                this.ukloniSveZanrove();
            });

        }

    }

    public addListeners(ref: any) {
        for(let i = 0; i < ref.children.length; i++) {
            // console.log("Didn't add listener: zanrovi.component.ts ln:63");
            (document.getElementById("baza-btn-" + i) as HTMLElement).addEventListener("click",
                    (btn: any) => {
                let val = JSON.parse(btn.target.placeholder);
                console.log("brisanjeeeee");
                this.ukloniZanr(val.id);
            });
            (document.getElementById("baza-btn-edit-" + i) as HTMLElement).addEventListener("click",
                    (btn: any) => {
                let val = JSON.parse(btn.target.placeholder);
                console.log("clicked edit button")
                let naziv = prompt("Unesite novi naziv za žanr " + val.naziv);
                if(naziv)
                    this.azurirajZanr(val.id, naziv);
            });
        }
    }

    async loadTMDBZanrovi() {

        (document.getElementById("dohvati") as HTMLElement).remove();
        // document.getElementById("dohvati").remove();
        let popisZanrovaTMDB = (document.getElementById("popis-zanrova-tmdb") as HTMLElement);
        // let popisZanrovaTMDB = document.getElementById("popis-zanrova-tmdb");
        popisZanrovaTMDB.innerHTML = "";

        let zanroviTMDB = await this.dohvatiTMDBZanrove();

        if(zanroviTMDB.length == 0) {
            popisZanrovaTMDB.innerHTML = "Nema pohranjenih zanrova na vanjskom servisu."
            return;
        }

        for(let i = 0; i < zanroviTMDB.length; i++) {
            let zanrHTML = "<li id='tmdb-item-" + i + "' class='zanr-tmdb'>" +
                                "<input id='tmdb-btn-" + i + "' class='zanr-tmdb-btn' " +
                                "type='button' value='Dodaj'" +
                                "placeholder='" + JSON.stringify(zanroviTMDB[i]) + "'/>" +
                                "\t" + zanroviTMDB[i]["name"] +
                            "</li>";
            popisZanrovaTMDB.innerHTML += zanrHTML;
        }

        setTimeout(() => {
            // console.log("Didn't add event listener for service: zanrovi.component.ts ln:104");
            for(let i = 0; i < zanroviTMDB.length; i++)
            (document.getElementById("tmdb-btn-" + i) as HTMLElement).addEventListener("click",
                    (btn: any) => {
                let val = JSON.parse(btn.target.placeholder);
                if(!this.contains(val.id))
                    this.dodajZanr(val.id, val.name);
                else alert(JSON.stringify(val) + " is already in the database as "
                    + JSON.stringify(this.get(val.id)))
            })
        }, 100);

        this.loadDodajSve(popisZanrovaTMDB);

    }

    loadDodajSve(ref: any) {

        ref.outerHTML += "<input id='dodaj-sve' class='zanr-tmdb-btn' type='button' " +
            "value='Dodaj sve žanrove'>";
        (document.getElementById("dodaj-sve") as HTMLElement).addEventListener("click",
                (btn: any) => this.dodajSveZanrove());
        // document.getElementById("dodaj-sve").addEventListener("click", (btn) => {
        //     dodajSveZanrove();
        // })

    }

    contains(val: any) {
        // let popisBaza = document.getElementById("popis-zanrova-baza" as HTMLElement).children;
        let popisBaza = (document.getElementById("popis-zanrova-baza") as HTMLElement).children;
        for(let i = 0; i < popisBaza.length; i++)
            if(JSON.parse((popisBaza[i].children[0] as any).placeholder).id == val)
                return true;
        return false;
    }

    get(val: any) {
        let popisBaza = (document.getElementById("popis-zanrova-baza") as HTMLElement).children;
        // let popisBaza = (document.getElementById("popis-zanrova-baza") as HTMLElement).children;
        for(let i = 0; i < popisBaza.length; i++)
            if(JSON.parse(((popisBaza[i].children[0]) as (HTMLInputElement)).placeholder).id == val)
                return JSON.parse((popisBaza[i].children[0] as (HTMLInputElement)).placeholder);
        return null;
    }

    async dodajSveZanrove() {
        
        let preskoceno = [];
        let zanroviTMDB = await this.dohvatiTMDBZanrove();
        
        let j = 0;
        for(let i = 0; i < zanroviTMDB.length; i++)
            if(!this.contains(zanroviTMDB[i]["id"]))
                await this.dodajZanrSve(zanroviTMDB[i]["id"], zanroviTMDB[i]["name"]);
            else 
                preskoceno[j++] = JSON.stringify(zanroviTMDB[i]);

        console.log("COMPARISON OF LISTS", zanroviTMDB.length, this.zanroviBaza.length)
        console.log(zanroviTMDB, this.zanroviBaza)
        if(preskoceno.length > 0) {
            alert("Neki žanrovi već postoje u bazi, pa su preskočeni: " + preskoceno)
        }
        
        this.loadBazaZanrovi();

    }

    async dohvatiZanroveIzBaze() {
        let odgovor = await fetch(this.url + "/dajSveZanrove");
        let podaci = await odgovor.text();
        // console.log(podaci);
        let zanrovi = JSON.parse(podaci);
        console.log(zanrovi)
        return zanrovi;
    }

    async dohvatiTMDBZanrove() {
        let odgovor = await fetch(this.url + "/dajTMDBZanrove");
        let podaci = await odgovor.text();
        // console.log(podaci);
        let zanrovi = JSON.parse(podaci).genres;
        console.log(zanrovi)
        return zanrovi;
    }

    async dodajZanr(zanr_id: any, zanr_naziv: any) {

        // console.log(zanr_id, zanr_naziv)
        await fetch(this.url + "/zanr/", {
            method: 'POST',
            headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: zanr_id, naziv: zanr_naziv })
        });

        this.loadBazaZanrovi();

    }

    async dodajZanrSve(zanr_id: any, zanr_naziv: any) {

        // console.log(zanr_id, zanr_naziv)
        await fetch(this.url + "/zanr/", {
            method: 'POST',
            headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: zanr_id, naziv: zanr_naziv })
        });

    }

    async azurirajZanr(id: any, zanr_naziv: any) {

        await fetch(this.url + "/zanr/" + id, {
            method: 'PUT',
            headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
            },
            body: JSON.stringify({ naziv: zanr_naziv })
        });

        this.loadBazaZanrovi();

    }

    async ukloniZanr(id: any) {

        await fetch(this.url + "/zanr/" + id, {
            method: 'DELETE',
            headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
            },
        });

        this.loadBazaZanrovi();

    }

    async ukloniSveZanrove() {
        
        await fetch(this.url + "/zanr/", {
            method: 'DELETE',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
        }).then(() => {
            this.loadBazaZanrovi();
        });

    }

    ngOnInit() {
        this.loadBazaZanrovi();
        (document.getElementById("dohvati") ?? new HTMLHeadElement()).addEventListener("click", () => {
            this.loadTMDBZanrovi();
        })
    }

}