import { Component, OnInit } from '@angular/core';
import * as env from '../../../environments/environment';
import { Pager } from '../../komponenti/stranicar/stranicar.component';

@Component({
    selector: 'app-filmovi-pregled',
    templateUrl: './filmovi-pregled.component.html',
    styleUrls: ['./filmovi-pregled.component.scss']
})

export class FilmoviPregledComponent implements OnInit {
  
    filmovi: any;
    ngOnInit() {
        this.ucitajSadrzaj();
    }

    async ucitajSadrzaj() {

        let filmContainer = document.getElementsByClassName("film-container")[0];
        let brojStranica = await maxStranica();
        this.filmovi = await dohvatiFilmove();
        
        let c = 0;
        
        // console.log(filmovi);
        if(await this.filmovi.length > 0) {
        
            for(let j = 0; j < this.filmovi.length; j++) {
        
                let id = this.filmovi[j]["id"];
                let naslov = this.filmovi[j]["naslov"];
                let datum = this.filmovi[j]["datum_izlaska"];
                datum = datum.substring(8, 10) + "." + datum.substring(5, 7) + "."
                    + datum.substring(0, 4);
                let poster = await this.filmovi[j]["poster_putanje"];
                let posterURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
                let hide = (++c > brojStranica) ? ' hidden' : '';
                let film = '<div class="film" ' + hide + '>'
                        + '<a style="text-decoration: none; color: inherit;" href="/film/'
                            + id + '" id="' + id + '">'
                        + '<img src="' + posterURL + poster + '" alt="Poster slika filma">'
                        + '<h1>' + naslov + '</h1>'
                        + '<p>'
                            + datum
                        + '</p>'
                    + '</a></div>';
                
                filmContainer.innerHTML += film;
        
            }
        
        }
        
        new Pager(brojStranica, 'needs-pager').showPage();

    }

}

let url = new env.okolina().app();

async function dohvatiFilmove() {
    let odgovor = await fetch(url + "/dajSveFilmove?prijedlozi=" + 0);
    let podaci = await odgovor.text();
    let filmovi = JSON.parse(podaci);
    return filmovi;
}

async function maxStranica() {
    let odgovor = await fetch(url + "/brojStranica");
    let podaci = await odgovor.text();
    let brojStranica = JSON.parse(podaci);
    // console.log("OKTRIVENO ", brojStranica)
    return brojStranica;
}