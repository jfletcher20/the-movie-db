import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { okolina } from '../../../environments/environment';
// import { DocSelectors } from '../../app.component';
import { NavComponent } from '../../komponenti/nav/nav.component';

@Component({
    selector: 'app-registracija',
    templateUrl: './registracija.component.html',
    styleUrls: ['./registracija.component.scss']
})

export class RegistracijaComponent implements OnInit {
    
    korisnik: any;

    constructor(private client: HttpClient, private router: Router) {
    }

    ngOnInit(): void {
        this.korisnik = {};
    }

    getKorisnik() {
        let ime = this.getElementById('ime');
        let prezime = this.getElementById('prezime');
        let email = this.getElementById('email');
        let korime = this.getElementById('korime');
        let lozinka = this.getElementById('lozinka');
        this.korisnik = {
            ime: ime.value,
            prezime: prezime.value,
            email: email.value,
            korime: korime.value,
            lozinka: lozinka.value,
        };
        // console.log(this.korisnik);
        return this.korisnik;
    }

    getValidniPodaci(korisnik: any) {
        if(korisnik.ime == '' || korisnik.ime == null
            || korisnik.ime == undefined)
            return false;
        if(korisnik.prezime == '' || korisnik.prezime == null
            || korisnik.prezime == undefined)
            return false;
        if(korisnik.email == '' || korisnik.email == null
            || korisnik.email == undefined)
            return false;
        if(korisnik.korime == '' || korisnik.korime == null
            || korisnik.korime == undefined)
            return false;
        if(korisnik.lozinka == '' || korisnik.lozinka == null
            || korisnik.lozinka == undefined)
            return false;
        return true;
    }

    registracija() {
        console.log("Registriranje...", this.getKorisnik());
        if(this.getValidniPodaci(this.getKorisnik()) == false) {
            let por = document.getElementById("poruka");
            por != null ? por.innerHTML = "<p style='color: red'>Krivi unos.</p>" : 0;
            return;
        } else {
            let por = document.getElementById("poruka");
            por != null ? por.innerHTML = "<p style='color: red'></p>" : 0;
            this.client.post(new okolina().app() + "/registracija", this.korisnik).subscribe(odgovor => {
                // console.log(this.korisnik);
                // console.log("ZAHTJEV ZA REGISTRACIJU", this.korisnik, odgovor)
                // console.log("Registriran je: ", odgovor);
                // new NavComponent().ucitajNavigaciju();
            });
            console.log("Navigiranje...");
            this.router.navigate(['/prijava'])
        }
    }

    private getElementById(id: string) {
        return document.getElementById(id) as HTMLInputElement ?? new HTMLInputElement(); 
    }

}
