import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { okolina } from '../../../environments/environment';
import { DocSelectors } from '../../app.component';
import { NavComponent } from '../../komponenti/nav/nav.component';

@Component({
    selector: 'app-prijava',
    templateUrl: './prijava.component.html',
    styleUrls: ['./prijava.component.scss']
})

export class PrijavaComponent implements OnInit {

    korisnik: any;

    constructor(private client: HttpClient, private router: Router) {
    }

    ngOnInit(): void {
        this.korisnik = {};
    }

    prijava() {
        if(this.getValidniPodaci(this.korisnik) == false) {
            let por = document.getElementById("poruka");
            (por != null) ? por.innerHTML = "<p style='color: red'>"
                + "Treba unijeti podatke za login." + "</p>" : 0;
            return;
        } else {
            let por = document.getElementById("poruka");
            (por != null) ? por.innerHTML = "<p style='color: red'>"
                + "" + "</p>" : 0;
            this.client.post(new okolina().app() + "/prijava", this.korisnik).subscribe(odgovor => {
                if((odgovor as any).greska) {
                    let por = document.getElementById("poruka");
                    por != null ? por.innerHTML = "<p style='color: red'>Krivi unos.</p>" : 0;
                    return;
                } else {
                    let prijavljen: PrijavljenOdgovor = odgovor as PrijavljenOdgovor;
                    console.log("Prijavljen je:", prijavljen.korime, prijavljen.tip_korisnika_id);
                    sessionStorage.setItem("jwt", prijavljen.jwt);
                    sessionStorage.setItem("korime", prijavljen.korime ?? "");
                    sessionStorage.setItem("tip_korisnika_id", prijavljen.tip_korisnika_id?.toString() ?? "0");
                    // console.log(sessionStorage.getItem("jwt"));
                    setTimeout(() => {
                        console.log("Navigiranje...");
                        this.router.navigate(['/'])
                    }, 300);
                    new NavComponent().ucitajNavigaciju();
                }
            });
        }
    }
    
    getValidniPodaci(korisnik: any) {
        if(korisnik.korime == '' || korisnik.korime == null
            || korisnik.korime == undefined)
            return false;
        if(korisnik.lozinka == '' || korisnik.lozinka == null
            || korisnik.lozinka == undefined)
            return false;
        return true;
    }

}

export class PrijavljenOdgovor {
    cookie: any;
    jwt: any;
    korime?: string;
    tip_korisnika_id?: number;
}