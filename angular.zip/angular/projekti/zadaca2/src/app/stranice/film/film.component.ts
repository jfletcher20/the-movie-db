import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { okolina } from '../../../environments/environment';

@Component({
    selector: 'app-film',
    templateUrl: './film.component.html',
    styleUrls: ['./film.component.scss']
})

export class FilmComponent implements OnInit {

    id: any;
    constructor(private router: Router) {
    }

    ngOnInit() {
        this.id = this.router.url.split("/")[2];
        console.log(this.id);
        this.ucitajFilm();
    }

    async ucitajFilm() {

        let filmContainer = document.getElementsByClassName("film-container")[0];
        filmContainer.classList.add("flex-horizontal");
        let film = await dohvatiFilm(this.id);
        console.log(await film);
        
        if(film != null) {

            let id = film["id"];
            let naslov = film["naslov"];
            let datum = film["datum_izlaska"];
            datum = parsiranDatum(datum);
            let poster = await film["poster_putanje"];
            let posterURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
            let filmPrikaz = '<div class="film" id="film">'
                    // + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" id="' + id + '">'
                    + '<img src="' + posterURL + poster + '" alt="Poster slika filma">'
                    + '<h1>' + naslov + '</h1>'
                    + '<p>'
                        + datum
                    + '</p>'
                    // + '</a>'
                + '</div>';
            
            filmContainer.innerHTML += filmPrikaz;

            prikaziPodatke(film);

            let veze = await vezeKorisnikIDFilma(film["id"]);
            if(veze != null)
                (document.getElementById("korime") as HTMLElement).innerText = veze.korime;

        }

    }
    
}

let url = new okolina().app();

function parsiranDatum(datum: string) {
    return datum.substring(8, 10) + "." + datum.substring(5, 7) + "." + datum.substring(0, 4) + ".";
}

async function dohvatiFilm(id: any)  {
    let odgovor = await fetch("/filmPodaci/" + id);
    let podaci = await odgovor.text();
    // console.log("/filmPodaci/" + document.getElementById('filmid').innerText)
    // console.log(JSON.parse(podaci));
    return JSON.parse(podaci);
}

let podaciFilma = '<div class="film-data">'
    + '<div id="opcenito" style="padding: 20px">'
        + '<h1>Općenito</h1>'
        + '<h2>Opis</h2>'
        + '<p id="pregled"></p>'
        + '<h2>Geslo</h2>'
        + '<p id="slogan"></p>'
        + '<h2>Status</h2>'
        + '<p id="status"></p>'
        + '<h2>Trajanje</h2>'
        + '<p id="trajanje"></p>'
        + '<h2>Za odrasle</h2>'
        // + '<input name="za_odrasle" id="za_odrasle" type="checkbox" disabled>'
        + '<p id="za_odrasle"></p>'
    + '</div>'
    + '<div id="brojevi" style="padding: 20px">'
        + '<h1>Statistika</h1>'
        + '<h2>Budžet</h2>'
        + '<p id="budzet"></p>'
        + '<h2>Prihod</h2>'
        + '<p id="prihod"></p>'
        + '<h2>Popularnost</h2>'
        + '<p id="popularnost">#</p>'
        + '<h2>Ocjena</h2>'
        + '<p id="prosjek_glasova">★&nbsp;</p>'
        + '<h2>Broj glasova</h2>'
        + '<p id="broj_glasova"></p>'
    + '</div>'
    + '<div id="dodatno" style="padding: 20px">'
        + '<h1>Dodatno</h1>'
        + '<h2>Dodano</h2>'
        + '<p id="datum_unosa"></p>'
        + '<h2>Korisnik</h2>'
        + '<p id="korime"></p>'
        // + '<i><p id="json"></p></i>'
    + '</div>'
+ '</div>';

function prikaziPodatke(filmPodaci: any) {

    let filmContainer = document.getElementsByClassName("film-container")[0];
    filmContainer.innerHTML += podaciFilma;

    let p = pKojiImaID();
    p.forEach(element => dodajPodatke(element.id, filmPodaci));

    let za_odrasle = document.getElementById("za_odrasle");
    if(filmPodaci["za_odrasle"] != 0)
        (za_odrasle as HTMLElement).innerHTML = "<p style='color: green;'>true</p>";
    else
        (za_odrasle as HTMLElement).innerHTML = "<p style='color: red;'>false</p>";

}

function dodajPodatke(idElementa: any, podaciJSON: any) {
    if(idElementa.toString().match('datum') == null) {
        (document.getElementById(idElementa) as HTMLElement).innerText
            += podaciJSON[idElementa];
    } else if(idElementa == "trajanje") {
        (document.getElementById(idElementa) as HTMLElement).innerText
            += " min";
    } else if(idElementa.toString().match('datum') != null)
        (document.getElementById(idElementa) as HTMLElement).innerText
            += parsiranDatum(podaciJSON[idElementa]);
}

function pKojiImaID() {
    let j = 0, pall = document.getElementsByTagName("p"), p = [];
    for(let i = 0; i < pall.length; i++)
        if(pall[i].id != '')
            p[j++] = pall[i];
    return p;
}

async function vezeKorisnikIDFilma(idFilma: any) {
    let odgovor = await fetch(url + "/korisniciImaFilm/" + idFilma);
    let podaci = await odgovor.text();
    return JSON.parse(podaci)[0];
}