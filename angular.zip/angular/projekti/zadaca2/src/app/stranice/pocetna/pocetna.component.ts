import { Component, OnInit } from '@angular/core';
import { Pager } from '../../komponenti/stranicar/stranicar.component';
import * as env from '../../../environments/environment'

@Component({
    selector: 'app-pocetna',
    templateUrl: './pocetna.component.html',
    styleUrls: ['./pocetna.component.scss']
})
export class PocetnaComponent implements OnInit {

    zanrovi: any;
    ngOnInit() {
        this.ucitajKomponente();
    }

    async ucitajKomponente() {

        let popisZanrova = document.getElementById("popis-zanrova");
        let brojStranica = await maxStranica();
        this.zanrovi = await dohvatiZanrove();
        let json = await dohvatiZanrove();
    
        let c = 0;
    
        if(json.length == 0) {
            if(popisZanrova != null)
                popisZanrova.innerHTML = "Nema pohranjenih zanrova u bazi podataka."
            return;
        }
        
        for(let i = 0; i < json.length; i++) {
    
            let filmContainer = document.getElementsByClassName("film-container")[0];
            let filmovi = await dohvatiFilmove(json[i]["id"]);
    
            if(filmovi.length > 0) {
    
                for(let j = 0; j < filmovi.length; j++) {
                    
                    let id = filmovi[j]["id"];
                    let naslov = filmovi[j]["naslov"];
                    let datum = filmovi[j]["datum_izlaska"];
                    datum = datum.substring(8, 10) + "." + datum.substring(5, 7) + "." + datum.substring(0, 4);
                    let poster = await filmovi[j]["poster_putanje"];
                    let posterURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
                    let hide = (++c > brojStranica) ? ' hidden' : '';
                    let film = '<div class="film" ' + hide + '>'
                            + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" id="' + id + '">'
                            + '<img src="' + posterURL + poster + '" alt="Poster slika filma">'
                            + '<h1>' + naslov + '</h1>'
                            + '<p>'
                                + datum
                            + '</p>'
                        + '</a></div>';
                    filmContainer.innerHTML += film;
    
                }
    
            }
    
        }
    
        new Pager(brojStranica, 'needs-pager').showPage();

    }

}

// const htmlUpravitelj = require("../htmlUpravitelj.js")
let url = new env.okolina().app();

async function maxStranica() {
    let odgovor = await fetch(url + "/brojStranica");
    let podaci = await odgovor.text();
    let brojStranica = JSON.parse(podaci);
    return brojStranica;
}

async function dohvatiZanrove() {
    let odgovor = await fetch(url + "/dajSveZanrove");
    let podaci = await odgovor.text();
    // console.log(podaci);
    let zanrovi = JSON.parse(podaci);
    return zanrovi;
}

async function dohvatiFilmove(zanr: any) {
    let odgovor = await fetch(url + "/dajDvaFilma?zanr=" + zanr);
    let podaci = await odgovor.text();
    let filmovi = JSON.parse(podaci);
    return filmovi;
}

/* // backup
import { Component, OnInit } from '@angular/core';
import { Pager } from '../../komponenti/stranicar/stranicar.component';
import * as env from '../../../environments/environment'
import { FilmPodaci } from '../../klase-podataka/film-podaci';

@Component({
    selector: 'app-pocetna',
    templateUrl: './pocetna.component.html',
    styleUrls: ['./pocetna.component.scss']
})
export class PocetnaComponent implements OnInit {

    zanrovi: any;
    filmovi: any;
    ngOnInit() {
        this.ucitajKomponente();
    }

    async ucitajKomponente() {

        let popisZanrova = document.getElementById("popis-zanrova");
        let brojStranica = await maxStranica();
        this.zanrovi = await dohvatiZanrove();
        let json = await dohvatiZanrove();
    
        let c = 0;
    
        if(json.length == 0) {
            if(popisZanrova != null)
                popisZanrova.innerHTML = "Nema pohranjenih zanrova u bazi podataka."
            return;
        }
        
        for(let i = 0; i < json.length; i++) {
    
            let filmContainer = document.getElementsByClassName("film-container")[0];
            this.filmovi += await dohvatiFilmove(json[i]["id"]);
    
            if(this.filmovi.length > 0) {
    
                for(let j = 0; j < this.filmovi.length; j++) {
                    this.filmovi[j].posterPoveznica = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/"
                        + this.filmovi[j].poster_putanje;
                    this.filmovi[j].poveznicaPregled = "/film/" + this.filmovi[j].id;
                    // let id = this.filmovi[j]["id"];
                    // let naslov = this.filmovi[j]["naslov"];
                    // let datum = this.filmovi[j]["datum_izlaska"];
                    // datum = datum.substring(8, 10) + "." + datum.substring(5, 7) + "." + datum.substring(0, 4);
                    // let poster = await this.filmovi[j]["poster_putanje"];
                    // let posterURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
                    // let hide = (++c > brojStranica) ? ' hidden' : '';
                    // let film = '<div class="film" ' + hide + '>'
                    //         + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" id="' + id + '">'
                    //         + '<img src="' + posterURL + poster + '" alt="Poster slika filma">'
                    //         + '<h1>' + naslov + '</h1>'
                    //         + '<p>'
                    //             + datum
                    //         + '</p>'
                    //     + '</a></div>';
                    // filmContainer.innerHTML += film;
    
                }
    
            }
    
        }
    
        new Pager(brojStranica, 'needs-pager').showPage();

    }

}

// const htmlUpravitelj = require("../htmlUpravitelj.js")
let url = new env.okolina().app();

// window.addEventListener("load", async () => {

//     let popisZanrova = document.getElementById("popis-zanrova");
//     let brojStranica = await maxStranica();
//     let zanrovi = await dohvatiZanrove();
//     let json = await zanrovi;

//     let c = 0;

//     if(json.length == 0) {
//       if(popisZanrova != null)
//         popisZanrova.innerHTML = "Nema pohranjenih zanrova u bazi podataka."
//       return;
//     }

//     for(let i = 0; i < json.length; i++) {
//         let zanrHTML = "<li class='zanr'>" + json[i]["naziv"] + "</li>";
//         if(popisZanrova != null)
//         popisZanrova.innerHTML += zanrHTML;
//     }
    
//     for(let i = 0; i < json.length; i++) {

//         let filmContainer = document.getElementsByClassName("film-container")[0];
//         let filmovi = await dohvatiFilmove(json[i]["id"]);

//         if(filmovi.length > 0) {

//             for(let j = 0; j < filmovi.length; j++) {
                
//                 let id = filmovi[j]["id"];
//                 let naslov = filmovi[j]["naslov"];
//                 let datum = filmovi[j]["datum_izlaska"];
//                 datum = datum.substring(8, 10) + "." + datum.substring(5, 7) + "." + datum.substring(0, 4);
//                 let poster = await filmovi[j]["poster_putanje"];
//                 let posterURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
//                 let hide = (++c > brojStranica) ? ' hidden' : '';
//                 let film = '<div class="film" ' + hide + '>'
//                         + '<a style="text-decoration: none; color: inherit;" href="/film/' + id + '" id="' + id + '">'
//                         + '<img src="' + posterURL + poster + '" alt="Poster slika filma">'
//                         + '<h1>' + naslov + '</h1>'
//                         + '<p>'
//                             + datum
//                         + '</p>'
//                     + '</a></div>';
//                 filmContainer.innerHTML += film;

//             }

//         }

//     }

//     new Pager(brojStranica, 'needs-pager').showPage();

// });

async function maxStranica() {
    let odgovor = await fetch(url + "/brojStranica");
    let podaci = await odgovor.text();
    let brojStranica = JSON.parse(podaci);
    return brojStranica;
}

async function dohvatiZanrove() {
    let odgovor = await fetch(url + "/dajSveZanrove");
    let podaci = await odgovor.text();
    // console.log(podaci);
    let zanrovi = JSON.parse(podaci);
    return zanrovi;
}

async function dohvatiFilmove(zanr: string) {
    let odgovor = await fetch(url + "/dajDvaFilma?zanr=" + zanr);
    let podaci = await odgovor.text();
    let filmovi = JSON.parse(podaci);
    return filmovi;
}
*/