import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { okolina } from '../../../environments/environment';
import { NavComponent } from '../../komponenti/nav/nav.component';

@Component({
    selector: 'app-profil',
    templateUrl: './profil.component.html',
    styleUrls: ['./profil.component.scss']
})

export class ProfilComponent implements OnInit {

    korisnik: any;

    constructor(private client: HttpClient, private router: Router) {
    }
    
    ngOnInit(): void {
        this.ucitajProfilVrijednosti();
    }

    getKorisnik() {
        let ime = this.getElementById('ime');
        let prezime = this.getElementById('prezime');
        let adresa = this.getElementById('adresa');
        // let email = this.getElementById('email');
        // let korime = this.getElementById('korime');
        let lozinka = this.getElementById('lozinka');
        this.korisnik = {
            ime: ime.value,
            prezime: prezime.value,
            adresa: adresa.value,
            // korime: korime.value,
            // email: korime.value,
            lozinka: lozinka.value,
        };
        console.log(this.korisnik);
        return this.korisnik;
    }

    profil() {
        if(this.getValidniPodaci(this.getKorisnik()) == false) {
            let por = document.getElementById("poruka");
            (por != null) ? por.innerHTML = "<p style='color: red'>"
                + "Samo adresa smije biti prazna." + "</p>" : 0;
            return;
        } else {
            let por = document.getElementById("poruka");
            (por != null) ? por.innerHTML = "<p style='color: red'>"
                + "</p>" : 0;
            this.client.post(new okolina().app() + "/profil", this.korisnik).subscribe((odgovor: any) => {
                // console.log(this.korisnik);
                // console.log("Uređivanje profila");
                // if((odgovor as any).greska) {
                //     let por = document.getElementById("poruka");
                //     (por != null) ? por.innerHTML = "<p style='color: red'>"
                //         + (odgovor as any).greska + "</p>" : 0;
                //     return;
                // } else {
                    // console.log("Profil je azuriran: ", odgovor);
                    console.log("Navigiranje...");
                    this.ucitajProfilVrijednosti();
                    // new NavComponent().ucitajNavigaciju();
                // }
            });
        }
    }

    async ucitajProfilVrijednosti() {
    
        var ime = document.getElementById("ime");
        var prezime = document.getElementById("prezime");
        var adresa = document.getElementById("adresa");
        // var lozinka = document.getElementById("lozinka");
        var korime = document.getElementById("korime");
        var email = document.getElementById("email");
    
        let kor = await new NavComponent().getKorisnik();
        console.log("UCITAN KORISNIK", kor);
        if(kor) {
            v(ime, kor.ime);
            v(prezime, kor.prezime);
            v(adresa, kor.adresa);
            v(korime, kor.korime);
            v(email, kor.email);
        }

    }
    
    private getElementById(id: string) {
        return document.getElementById(id) as HTMLInputElement ?? new HTMLInputElement(); 
    }
    
    getValidniPodaci(korisnik: any) {
        if(korisnik.ime == '' || korisnik.ime == null
            || korisnik.ime == undefined)
            return false;
        if(korisnik.prezime == '' || korisnik.prezime == null
            || korisnik.prezime == undefined)
            return false;
        if(korisnik.lozinka == '' || korisnik.lozinka == null
            || korisnik.lozinka == undefined)
            return false;
        return true;
    }

}

function v(obj: any, val: any) {
    obj.value = val;
}
