import { Component } from '@angular/core';

@Component({
    selector: 'app-dokumentacija',
    templateUrl: './dokumentacija.component.html',
    styleUrls: ['./dokumentacija.component.scss']
})
export class DokumentacijaComponent {

}
