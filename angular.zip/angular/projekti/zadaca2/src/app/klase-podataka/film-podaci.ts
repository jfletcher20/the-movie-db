export class FilmPodaci {
    id: any;
    imdb_id: any;
    za_odrasle: any;
    bd_putanje: any;
    pripada_kolekciji: any;
    budzet: any;
    pocetna_stranica: any;
    originalni_jezik: any;
    originalni_naslov: any;
    pregled: any;
    popularnost: any;
    poster_putanje: any;
    datum_izlaska: any;
    prihod: any;
    trajanje: any;
    status: any;
    slogan: any;
    naslov: any;
    video: any;
    prosjek_glasova: any;
    broj_glasova: any;
    datum_unosa: any;
    prijedlog: any;
    posterPoveznica: string | null | undefined;
    poveznicaPregled: any;
}