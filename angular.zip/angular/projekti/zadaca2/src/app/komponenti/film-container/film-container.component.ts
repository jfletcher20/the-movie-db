import { Component } from '@angular/core';
import { PocetnaComponent } from '../../stranice/pocetna/pocetna.component';

@Component({
    selector: 'app-film-container',
    templateUrl: './film-container.component.html',
    styleUrls: ['./film-container.component.scss']
})

export class FilmContainerComponent {
    filmovi: any;
}
