import { Component, OnInit } from '@angular/core';
import { okolina } from '../../../environments/environment';

@Component({
    selector: 'app-nav',
    templateUrl: './nav.component.html',
    styleUrls: ['./nav.component.scss']
})

export class NavComponent implements OnInit {

    ngOnInit() {
        this.ucitajNavigaciju();
    }

    odjava() {
        sessionStorage.removeItem('tip_korisnika_id');
        sessionStorage.removeItem('korime');
        sessionStorage.removeItem('jwt');
        this.ucitajNavigaciju();
    }

    parsiranDatum(datum: string) {
        return datum.substring(8, 10) + "." + datum.substring(5, 7) + "." + datum.substring(0, 4) + ".";
    }

    async getJWT() {
        // console.log("GETJWT")
        let odgovor = await fetch(new okolina().app() + "/prijavljen");
        let podaci = await odgovor.text();
        return podaci;
    }
    
    async getKorisnik() {
        let jwt = JSON.parse(await this.getJWT());
        // console.log("Get korisnik vratio ", jwt);
        if(jwt.korime == "Nije prijavljen") return null;
        let odgovor = await fetch("/korisnik/" + jwt.korime)
        let podaci = await odgovor.text();
        // console.log("[nav.component.ts ln:30]:", JSON.parse(podaci));
        return JSON.parse(podaci);
    }

    sakrij(arr: any) {
        if(arr.length == 0) return;
        for(let i = 0; i < arr.length; i++)
            arr[i].hidden = true;
    }

    prikazi(arr: any) {
        if(arr.length == 0) return;
        for(let i = 0; i < arr.length; i++)
            arr[i].hidden = false;
    }

    async ucitajNavigaciju() {
        let gost = document.getElementsByClassName("gost");
        let korisnik = document.getElementsByClassName("korisnik");
        let admin = document.getElementsByClassName("admin");
        let korSesija: KorisnikSesija = {
            korime: sessionStorage.getItem('korime'),
            tip_korisnika_id: Number.parseInt(sessionStorage.getItem('tip_korisnika_id') ?? "0"),
        };
        if(korSesija.korime == null || korSesija.korime == undefined) {
            let kor = await this.getKorisnik();
            if(kor == null) {
                this.sakrij(korisnik);
                this.sakrij(admin);
                this.prikazi(gost);
            } else if (kor.tip_korisnika_id == 0) {
                this.sakrij(admin);
                this.sakrij(gost);
                this.prikazi(korisnik);
            } else if (kor.tip_korisnika_id == 1) {
                this.sakrij(korisnik);
                this.sakrij(gost);
                this.prikazi(admin);
            }
            // this.redirectAkoNaKrivojStranici(kor);
        } else if(korSesija.tip_korisnika_id != null && korSesija.tip_korisnika_id != undefined) {
            let kor = { tip_korisnika_id: korSesija.tip_korisnika_id };
            if(kor == null) {
                this.sakrij(korisnik);
                this.sakrij(admin);
                this.prikazi(gost);
            } else if (kor.tip_korisnika_id == 0) {
                this.sakrij(admin);
                this.sakrij(gost);
                this.prikazi(korisnik);
            } else if (kor.tip_korisnika_id == 1) {
                this.sakrij(korisnik);
                this.sakrij(gost);
                this.prikazi(admin);
            }
            // this.redirectAkoNaKrivojStranici(kor);
        }
    }

    // redirectAkoNaKrivojStranici(korisnik: any) {
    //     if(korisnik != null)
    //         if(window.location.href.split("/")[3].toLowerCase() == "film") return;
    //     if(korisnik == null)
    //         if(window.location.href.split("/")[3].toLowerCase() == "film") {
    //             // window.location = putanje + "/prijava";
    //             return;
    //         }
    //     ((document.getElementById('a' + (window.location.href ?? "").split("/")[3].toLowerCase()) ?? new HTMLHeadElement()).parentElement ?? new HTMLHeadElement()).hidden;
    //     // if(skriveno)
    //         // window.location = putanje + "/prijava";
    // }

}

class KorisnikSesija {
    korime: string | null | undefined;
    tip_korisnika_id: number | null | undefined;
}