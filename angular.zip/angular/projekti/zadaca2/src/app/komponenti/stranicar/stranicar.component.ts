import { Component } from '@angular/core';
import { okolina } from '../../../environments/environment';

@Component({
    selector: 'app-stranicar',
    templateUrl: './stranicar.component.html',
    styleUrls: ['./stranicar.component.scss']
})
export class StranicarComponent {

    public async maxStranica() {
        let odgovor = await fetch(new okolina().app() + "/brojStranica");
        let podaci = await odgovor.text();
        let brojStranica = JSON.parse(podaci);
        return brojStranica;
    }
  
}

export class Pager {

    public start: any;
    public previous: any;
    public next: any;
    public end: any;

    public limit: any;
    public btns: any;
    public collection: any;
    public totalChildren: any;
    public totalPages: any;
    public currentPage: number;

    initializeEventListeners() {
        this.start.addEventListener("click", () => this.firstPage());
        this.previous.addEventListener("click", () => this.previousPage());
        this.next.addEventListener("click", () => this.nextPage());
        this.end.addEventListener("click", () => this.lastPage());
    }
    
    constructor(limit: number, collectionID: string) {
        //cont
        this.limit = limit;
        this.btns = document.getElementsByClassName('paging-btn');
        this.collection = document.getElementById(collectionID);
        var c = this.collection.children.length;
        //data // total range of [1, 500]
        this.totalChildren = c > 500 ? 500 : c < 1 ? 1 : c;
        this.totalPages = Math.floor(this.totalChildren / this.limit)
            + (this.totalChildren % this.limit > 0 ? 1 : 0);
        this.totalPages = this.totalPages < 1 ? 1 : this.totalPages > 500 ? 500 : this.totalPages;
        this.currentPage = parseInt((document.getElementsByClassName('stranica')[0].textContent ?? "1/1").split("/")[0]);
        this.updatePageText(this.currentPage);
        //contr
        this.start = this.btns[0];
        this.previous = this.btns[1];
        this.next = this.btns[2];
        this.end = this.btns[3];
        this.initializeEventListeners();
    }

    buttonsState(state: boolean) {
        this.start.disabled = state;
        this.previous.disabled = state;
        this.next.disabled = state;
        this.end.disabled = state;
    }

    buttonsPreviousState(state: boolean) {
        this.start.disabled = state;
        this.previous.disabled = state;
    }

    buttonsNextState(state: boolean) {
        this.next.disabled = state;
        this.end.disabled = state;
    }

    updatePageText(text: any) {
        document.getElementsByClassName('stranica')[0].textContent =
            text + "/" + this.totalPages;
    }

    showPage() {
        try {
            if(this.currentPage == 1) {
                this.buttonsPreviousState(true);
                this.buttonsNextState(false);
            } else if(this.currentPage == this.totalPages) {
                this.buttonsPreviousState(false);
                this.buttonsNextState(true);
            } else this.buttonsState(false);
            let i = (this.currentPage - 1) * this.limit;
            let j = 0;
            for(j; j < i; j++)
                this.collection.children[j].hidden = true;
            for(i; i < this.currentPage * this.limit && i < this.totalChildren; i++)
                this.collection.children[i].hidden = false;
            for(i; i < this.totalChildren; i++)
                this.collection.children[i].hidden = true;
        } catch(e) { this.buttonsNextState(true); }
    }

    nextPage() {
        try {
            if(this.currentPage < this.totalPages) {
                this.updatePageText(++this.currentPage);
                this.showPage();
            }
        } catch(e) { this.buttonsNextState(true); }
    }

    previousPage() {
        try {
            if(this.currentPage > 1) {
                this.updatePageText(--this.currentPage);
                this.showPage();
            }
        } catch(e) { this.buttonsPreviousState(true); }
    }

    firstPage() {
        try {
            this.currentPage = 1;
            this.updatePageText(this.currentPage);
            this.showPage();
        } catch(e) { this.buttonsPreviousState(true); }
    }

    lastPage() {
        try {
            this.currentPage = this.totalPages;
            this.updatePageText(this.currentPage);
            this.showPage();
        } catch(e) { this.buttonsNextState(true); }
    }

}