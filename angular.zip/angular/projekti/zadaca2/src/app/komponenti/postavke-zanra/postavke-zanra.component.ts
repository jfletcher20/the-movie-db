import { Component } from '@angular/core';

@Component({
  selector: 'app-postavke-zanra',
  templateUrl: './postavke-zanra.component.html',
  styleUrls: ['./postavke-zanra.component.scss']
})
export class PostavkeZanraComponent {

}
