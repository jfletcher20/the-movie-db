import { Component } from '@angular/core';

@Component({
    selector: 'app-re-captcha',
    templateUrl: './re-captcha.component.html',
    styleUrls: ['./re-captcha.component.scss']
})

export class ReCaptchaComponent {
    captcha() {
        console.log("CLICKED CAPTCHA")
    }
}
