import { Component } from '@angular/core';
import { FilmPodaci } from '../../klase-podataka/film-podaci';

@Component({
    selector: 'app-film-kartica',
    templateUrl: './film-kartica.component.html',
    styleUrls: ['./film-kartica.component.scss']
})

export class FilmKarticaComponent {
    posterURL: string = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/";
    poveznica: string = "/film/";
    film: FilmPodaci;
    constructor(film: FilmPodaci) {
        film.datum_izlaska = film.datum_izlaska.substring(8, 10)
            + "." + film.datum_izlaska.substring(5, 7) + "." + film.datum_izlaska.substring(0, 4);
        this.poveznica += film.id;
        this.film = film;
    }
}
