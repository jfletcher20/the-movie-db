import { Component } from '@angular/core';
// import { Pager } from './komponenti/stranicar/stranicar.component';
// import * as env from '../environments/environment';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})
export class AppComponent {
    title = 'zadaca2';
}

export class DocSelectors {
    constructor() { }
    public lambda = new HTMLElement();
    public getElementById(id: string) {
        return document.getElementById(id) ?? this.lambda; 
    }
    public getElementsByClassName(className: string) {
        return document.getElementsByClassName(className) ?? [this.lambda];
    }
    public getElementsByTagName(tagName: string) {
        return document.getElementsByTagName(tagName) ?? [this.lambda];
    }
}
