import { CanActivate, Router } from "@angular/router";
import { Injectable } from "@angular/core";
import { NavComponent } from "../komponenti/nav/nav.component";

@Injectable({providedIn: "root"})
export class AdminGuard implements CanActivate {

    constructor(private router: Router) {
    }

    async canActivate() {

        let navComp = new NavComponent();
        let kor = await navComp.getKorisnik();

        // console.log("USER FOUND IS ", kor != null ?
        //     (JSON.stringify(kor)).substring(0, 30) + "..." : null);

        if(kor == null) {
            await setTimeout(() => false, 2000);
            this.router.navigate(['/prijava']);
            return false;
        } else if(kor.tip_korisnika_id != 1) {
            console.log("Korisnik nije administrator.")
            this.router.navigate(['/pocetna']);
            return false;
        }
        
        // console.log("DISCOVERED ADMIN")
        return true;
    }

}