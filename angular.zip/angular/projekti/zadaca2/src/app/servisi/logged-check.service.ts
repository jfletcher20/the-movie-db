import { CanActivate, Router } from "@angular/router";
import { Injectable } from "@angular/core";
import { NavComponent } from "../komponenti/nav/nav.component";

@Injectable({providedIn: "root"})
export class LoggedGuard implements CanActivate {

    constructor(private router: Router) {
    }

    async canActivate() {
        let navComp = new NavComponent();
        let kor = await navComp.getKorisnik();
        // console.log("USER FOUND IS ", kor);
        if(kor != null) {
            this.router.navigate(['/']);
            return false;
        }
        return true;
    }

}