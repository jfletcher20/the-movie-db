export const environment = {
    production: false,
    baseURL: "http://localhost",
    app: "4202",
    rest: "4201",
    posteriPutanja: "https://image.tmdb.org/t/p/w600_and_h900_bestv2/"
}

export class okolina {
    public app() {
        return environment.baseURL + ":" + environment.app;
    }
    public rest() {
        return environment.baseURL + ":" + environment.rest;
    }
}