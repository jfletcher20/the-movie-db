export const environment = {
    production: true,
    baseURL: "http://localhost",
    app: "4202",
    rest: "4201",
    posteriPutanja: "https://image.tmdb.org/t/p/w600_and_h900_bestv2/"
}